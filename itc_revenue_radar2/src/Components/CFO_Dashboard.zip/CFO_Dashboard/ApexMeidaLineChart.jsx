import React, { useState, useMemo } from "react";
import Chart from "react-apexcharts";

const CampaignSalesChart = ({ tilldate, heading = "Heading Required", campaignData = [], previousFY, currentFY }) => {
    // Extract unique quarters
    const quarters = useMemo(() => {
        const qtrs = [...new Set(campaignData.map((item) => item.quarter))];
        return qtrs.sort(); // Q1 -> Q4
    }, [campaignData]);

    // Selected quarter
    const [selectedQuarter, setSelectedQuarter] = useState(quarters[0] || "");

    // Filter campaign data based on selected quarter and non-zero sales
    const filteredData = useMemo(
        () => campaignData.filter((item) => item.quarter === selectedQuarter && (item.previous_fy !== 0 || item.current_fy !== 0)),
        [campaignData, selectedQuarter]
    );

    // Chart categories: campaign names
    const categories = filteredData.map((item) => item.attribute_name);

    // Series for previous and current FY (in Crores)
    const previousFYSeries = filteredData.map((item) => Number((item.previous_fy / 10000000).toFixed(2)));
    const currentFYSeries = filteredData.map((item) => Number((item.current_fy / 10000000).toFixed(2)));

    // Apex Line Chart options
    const chartOptions = {
        chart: {
            type: "line",
            toolbar: { show: true },
            zoom: { enabled: true },
        },
        stroke: {
            curve: "smooth", // smooth lines
            width: 3,
        },
        markers: {
            size: 5,
            hover: { size: 7 },
        },
        xaxis: {
            categories: categories,
            title: { text: "Campaign" },
            labels: {
                rotate: -20,
                rotateAlways: false,
                trim: true,
                style: { fontSize: "10px", fontWeight: 500 },
            },
        },
        yaxis: {
            title: { text: "Sales (₹ in Crores)" },
            labels: {
                formatter: (val) => `₹ ${val}`,
            },
        },
        tooltip: {
            y: {
                formatter: (val) =>
                    val === 0
                        ? `₹ 0`
                        : `₹ ${Number(val).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
            },
        },
        colors: ["#878006", "#087211"], // Previous vs Current FY
        dataLabels: {
            enabled: true,
            formatter: (val) =>
                val === 0
                    ? ""
                    : `₹${Number(val).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
            style: { fontSize: "12px", fontWeight: 500, colors: ["#000"] },
        },
        legend: { position: "bottom" },
    };

    const series = [
        {
            name: `${previousFY} - (${tilldate.split("-")[0]} - ${Number(tilldate.split("-")[1]) - 1})`,
            data: previousFYSeries,
        },
        {
            name: `${currentFY} - (${tilldate})`,
            data: currentFYSeries,
        },
    ];

    return (
        <div className="card shadow-sm p-3">
            <h5 className="fw-semibold mb-3">{heading}</h5>

            {/* Quarter Filter */}
            <div className="mb-3">
                {quarters.map((qtr) => (
                    <button
                        key={qtr}
                        className={`btn btn-sm me-2 ${qtr === selectedQuarter ? "btn-secondary" : "btn-outline-secondary"}`}
                        onClick={() => setSelectedQuarter(qtr)}
                    >
                        {qtr}
                    </button>
                ))}
            </div>

            {/* Apex Line Chart */}
            {categories.length > 0 ? (
                <Chart options={chartOptions} series={series} type="line" height={350} />
            ) : (
                <p className="text-center text-muted">No data available for this quarter</p>
            )}
        </div>
    );
};

export default CampaignSalesChart;