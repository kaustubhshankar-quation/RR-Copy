import React, { useMemo } from "react";
import Chart from "react-apexcharts";

const ApexMediaRoiBarChart = ({ brand, yearly_roi, previous_fy, current_fy }) => {
  // Prepare series for ApexCharts
  const series = useMemo(() => {
    return yearly_roi.map((item) => ({
      name: item.media_group,
      data: [item.previous_fy, item.current_fy],
    }));
  }, [yearly_roi]);

  // X-axis labels
  const categories = [previous_fy, current_fy];

  // Chart options for bar chart
  const options = {
    chart: {
      type: "bar",
      height: 350,
      toolbar: { show: true },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: "50%",
        dataLabels: {
          position: "top",
        },
      },
    },
    dataLabels: {
      enabled: true,
      formatter: (val) => val.toFixed(2),
      offsetY: -10,
      style: {
        fontSize: "12px",
        colors: ["#304758"],
      },
    },
    xaxis: {
      categories: categories,
      title: { text: "Financial Year" },
    },
    yaxis: {
      title: { text: "ROI" },
      labels: {
        formatter: (val) => val.toFixed(2),
      },
    },
    tooltip: {
      y: {
        formatter: (val) => `${val} ROI`,
      },
    },
    legend: {
      position: "bottom",
      horizontalAlign: "center",
    },
  };

  return (
    <div className="accordion mt-3" id="roiAccordion">
      <div className="accordion-item border-0 shadow-sm">
        <h2 className="accordion-header" id="headingROI">
          <button
            className="accordion-button fw-semibold"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#collapseROI"
            aria-expanded="false"
            aria-controls="collapseROI"
          >
            📊 Media-wise ROI
          </button>
        </h2>
        <div
          id="collapseROI"
          className="accordion-collapse collapse"
          aria-labelledby="headingROI"
          data-bs-parent="#roiAccordion"
        >
          <div className="accordion-body">
            <Chart options={options} series={series} type="bar" height={350} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApexMediaRoiBarChart;